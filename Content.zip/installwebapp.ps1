Import-module IISAdministration
Import-Module WebAdministration
New-NetFirewallRule -DisplayName "Allow Silviu 8080" -Direction Inbound -LocalPort 8080 -Protocol TCP -Action Allow

dism /online /enable-feature /featurename:IIS-BasicAuthentication
Add-WindowsFeature NET-Framework-45-ASPNET
Add-WindowsFeature Web-Asp-Net45
Add-WindowsFeature Web-Server

Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-ServiceModel'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-AspNetCoreModule'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-AspNetCoreModuleV2'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-CertificateMappingAuthenticationModule'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-UrlAuthorizationModule'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-WindowsAuthenticationModule'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-DigestAuthenticationModule'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-IISCertificateMappingAuthenticationModule'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-IpRestrictionModule'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-DynamicIpRestrictionModule'
Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-ApplicationRequestRouting'

Enable-WindowsOptionalFeature -Online -FeatureName IIS-ASPNET, IIS-ManagementConsole -All
Enable-WindowsOptionalFeature -Online -FeatureName 'IIS-ASP'
Enable-WindowsOptionalFeature -Online -FeatureName 'IIS-IISCertificateMappingAuthentication'
Enable-WindowsOptionalFeature -Online -FeatureName 'IIS-ClientCertificateMappingAuthentication'
Enable-WindowsOptionalFeature -Online -FeatureName 'IIS-URLAuthorization'
Enable-WindowsOptionalFeature -Online -FeatureName 'IIS-WindowsAuthentication'
Enable-WindowsOptionalFeature -Online -FeatureName 'IIS-DigestAuthentication'
Enable-WindowsOptionalFeature -Online -FeatureName 'IIS-IPSecurity'

cd C:\webapp
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$temp_path = "C:\webapp\"

$wd_installer_url = "https://download.microsoft.com/download/0/1/D/01DC28EA-638C-4A22-A57B-4CEF97755C6C/WebDeploy_amd64_en-US.msi"
$wd_installer_file = $temp_path + [System.IO.Path]::GetFileName( $wd_installer_url )
Invoke-WebRequest -Uri $wd_installer_url -OutFile $wd_installer_file

$rw_installer_url = "https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi"
$rw_installer_file = $temp_path + [System.IO.Path]::GetFileName( $rw_installer_url )
Invoke-WebRequest -Uri $rw_installer_url -OutFile $rw_installer_file

$whb_installer_url = "https://download.visualstudio.microsoft.com/download/pr/016c6447-764a-4210-a260-bf7a2880d5c0/a5746437a3862d7803284ae8c2290200/dotnet-hosting-8.0.1-win.exe"
$whb_installer_file = $temp_path + [System.IO.Path]::GetFileName( $whb_installer_url )
Invoke-WebRequest -Uri $whb_installer_url -OutFile $whb_installer_file

Start-Process .\rewrite_amd64_en-US.msi -ArgumentList "/quiet"
Start-Process .\WebDeploy_amd64_en-US.msi -ArgumentList "/quiet"
Start-Process .\dotnet-hosting-8.0.1-win.exe -ArgumentList "/quiet"
Start-Sleep -Seconds 120

IISReset

New-WebAppPool -Name "webapp"
New-IISSite -Name "webapp" -PhysicalPath C:\webapp -BindingInformation "*:8080:"
Set-ItemProperty 'IIS:\Sites\webapp' applicationPool webapp
New-WebApplication -Name "webapp" -Site "webapp" -PhysicalPath C:\webapp -ApplicationPool "webapp"


Get-IISSite